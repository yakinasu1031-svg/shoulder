import type { MetadataRoute } from "next";
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "肩たたき券",
    short_name: "肩たたき券",
    description: "家族で使う肩たたき券",
    start_url: "/",
    display: "standalone",
    background_color: "#f7f7f3",
    theme_color: "#f7f7f3",
    icons: []
  };
}
