import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "肩たたき券",
  description: "家族で共有する肩たたき券",
  applicationName: "肩たたき券",
  appleWebApp: { capable: true, statusBarStyle: "default", title: "肩たたき券" },
};
export const viewport: Viewport = {
  width: "device-width", initialScale: 1, maximumScale: 1, viewportFit: "cover",
  themeColor: "#f7f7f3"
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ja"><body>{children}</body></html>;
}
