"use client";

import { useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Hand, History, LogOut, Plus, RotateCcw, Settings, ShieldCheck, Ticket, UserRound, Users } from "lucide-react";

type Profile = { id: string; display_name: string; role: "admin" | "member" };
type Account = { id: string; initial_count: number; balance: number; recipient_user_id: string };
type FamilyProfile = { id: string; display_name: string; role: "admin" | "member"; is_active: boolean };
type Tx = {
  id: string; type: string; amount: number; balance_before: number; balance_after: number;
  created_at: string; actor_name: string | null; note: string | null; reversal_of: string | null;
};

const supabase = createClient();

function dateLabel(value: string) {
  return new Intl.DateTimeFormat("ja-JP", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
}
function typeLabel(type: string) {
  return ({ use: "使用", add: "追加", reverse: "取り消し", reset: "リセット" } as Record<string,string>)[type] ?? type;
}

export default function Home() {
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [familyProfiles, setFamilyProfiles] = useState<FamilyProfile[]>([]);
  const [recipientId, setRecipientId] = useState("");
  const [account, setAccount] = useState<Account | null>(null);
  const [history, setHistory] = useState<Tx[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [message, setMessage] = useState("");
  const [tab, setTab] = useState<"home"|"history"|"admin">("home");
  const [addCount, setAddCount] = useState("5");
  const [initialCount, setInitialCount] = useState("10");
  const [resetCount, setResetCount] = useState("10");
  const [showUseConfirm, setShowUseConfirm] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showAddConfirm, setShowAddConfirm] = useState(false);
  const [cancelId, setCancelId] = useState<string | null>(null);

  const isAdmin = profile?.role === "admin";
  const remaining = account?.balance ?? 0;

  async function refresh() {
    const { data: { user: current } } = await supabase.auth.getUser();
    setUser(current);
    if (!current) { setProfile(null); setAccount(null); setHistory([]); setLoading(false); return; }
    const [{ data: p }, { data: a }, { data: h }, { data: people }] = await Promise.all([
      supabase.from("profiles").select("id,display_name,role").eq("id", current.id).maybeSingle(),
      supabase.from("ticket_accounts").select("id,initial_count,balance,recipient_user_id").limit(1).maybeSingle(),
      supabase.from("transactions").select("id,type,amount,balance_before,balance_after,created_at,actor_name,note,reversal_of").order("created_at", { ascending: false }).limit(100),
      supabase.from("profiles").select("id,display_name,role,is_active").order("created_at", { ascending: true })
    ]);
    setProfile(p as Profile | null);
    setAccount(a as Account | null);
    setHistory((h ?? []) as Tx[]);
    setLoading(false);
  }

  useEffect(() => {
    refresh();
    const { data: { subscription } } = supabase.auth.onAuthStateChange(() => { window.setTimeout(() => { refresh(); }, 0); });
    const channel = supabase.channel("ticket-live").on("postgres_changes", { event: "*", schema: "public", table: "ticket_accounts" }, () => refresh()).on("postgres_changes", { event: "*", schema: "public", table: "transactions" }, () => refresh()).subscribe();
    return () => { subscription.unsubscribe(); supabase.removeChannel(channel); };
  }, []);

  async function signIn(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false); if (error) setMessage(error.message); else await refresh();
  }
  async function signUp(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    const { error } = await supabase.auth.signUp({ email, password, options: { data: { display_name: displayName } } });
    setBusy(false);
    setMessage(error ? error.message : "登録申請を受け付けました。メール確認が必要な場合は案内に従ってください。管理者による権限設定後に利用できます。");
  }
  async function rpc(name: string, args: Record<string, unknown>) {
    setBusy(true); setMessage("");
    const { error } = await supabase.rpc(name, args);
    setBusy(false);
    if (error) setMessage(error.message);
    else { setMessage("処理が完了しました。"); await refresh(); }
  }
  async function signOut() { await supabase.auth.signOut(); await refresh(); }

  if (loading) return <main className="center"><div className="loader"/>読み込み中…</main>;

  if (!user) return (
    <main className="auth-wrap">
      <section className="auth-card">
        <div className="brand-mark"><Hand size={28}/></div>
        <p className="eyebrow">FAMILY TICKET</p>
        <h1>肩たたき券</h1>
        <p className="muted">家族で使える、肩たたきの約束。</p>
        <form onSubmit={signIn} className="stack">
          <label>メールアドレス<input type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} required /></label>
          <label>パスワード<input type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} required /></label>
          <button className="primary" disabled={busy}>ログイン</button>
        </form>
        <details className="signup">
          <summary>家族アカウントを新規登録</summary>
          <form onSubmit={signUp} className="stack">
            <label>表示名<input value={displayName} onChange={e=>setDisplayName(e.target.value)} required /></label>
            <label>メールアドレス<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required /></label>
            <label>パスワード（8文字以上）<input type="password" minLength={8} value={password} onChange={e=>setPassword(e.target.value)} required /></label>
            <button className="secondary" disabled={busy}>アカウントを登録</button>
          </form>
        </details>
        {message && <p className="notice">{message}</p>}
      </section>
    </main>
  );

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand"><span className="brand-mark small"><Hand size={19}/></span><span>肩たたき券</span></div>
        <div className="user-pill"><span className="avatar"><UserRound size={15}/></span>{profile?.display_name ?? user.email}{isAdmin && <span className="admin-dot">管理者</span>}</div>
      </header>

      <section className="welcome">
        <p className="eyebrow">FAMILY TICKET</p>
        <h1>今日も、ありがとう。</h1>
        <p className="muted">お母さんへの肩たたき券</p>
      </section>

      <section className="balance-card">
        <div className="balance-top"><span>現在の残り枚数</span><Ticket size={20}/></div>
        <div className="balance-number">{account ? remaining : "—"}<small>枚</small></div>
        <p>{account ? `初期設定 ${account.initial_count} 枚` : "チケットがまだ設定されていません"}</p>
        <button className="use-button" disabled={!account || remaining <= 0 || busy} onClick={()=>setShowUseConfirm(true)}>
          <Hand size={20}/> 肩たたき券を使う
        </button>
        {remaining <= 0 && account && <small className="low-note">残り枚数がありません。管理者に追加を依頼してください。</small>}
      </section>

      <nav className="tabs">
        <button className={tab==="home"?"active":""} onClick={()=>setTab("home")}><Ticket size={17}/>ホーム</button>
        <button className={tab==="history"?"active":""} onClick={()=>setTab("history")}><History size={17}/>履歴</button>
        {isAdmin && <button className={tab==="admin"?"active":""} onClick={()=>setTab("admin")}><Settings size={17}/>管理</button>}
      </nav>

      {tab==="home" && <section className="panel">
        <div className="section-heading"><h2>最近の履歴</h2><button className="text-button" onClick={()=>setTab("history")}>すべて見る</button></div>
        {history.slice(0,3).length ? history.slice(0,3).map(tx=><HistoryRow key={tx.id} tx={tx}/>) : <p className="empty">まだ履歴はありません。</p>}
      </section>}

      {tab==="history" && <section className="panel">
        <div className="section-heading"><h2>使用・操作履歴</h2><span className="count">{history.length}件</span></div>
        <p className="muted small-text">履歴は新しい順に表示されます。</p>
        {history.length ? history.map(tx=><div key={tx.id}><HistoryRow tx={tx}/>{isAdmin && tx.type==="use" && !tx.reversal_of && <button className="undo-link" onClick={()=>setCancelId(tx.id)}>この使用を取り消す</button>}</div>) : <p className="empty">まだ履歴はありません。</p>}
      </section>}

      {tab==="admin" && isAdmin && <section className="panel admin-panel">
        <div className="section-heading"><h2>管理者メニュー</h2><ShieldCheck size={19}/></div>
        <div className="admin-box">
          <h3><Plus size={18}/> 券を追加</h3>
          <p className="muted small-text">追加した枚数も履歴に記録されます。</p>
          <div className="inline-form"><input type="number" min="1" max="10000" value={addCount} onChange={e=>setAddCount(e.target.value)}/><span>枚</span><button className="secondary" disabled={busy || Number(addCount)<1} onClick={()=>setShowAddConfirm(true)}>追加</button></div>
        </div>
        <div className="admin-box">
          <h3><Settings size={18}/> 初期枚数の設定</h3>
          <p className="muted small-text">初回セットアップ時の枚数を指定します。現在の残数を変更する操作とは分けて管理します。</p>
          <label className="recipient-select">券を受け取る人<select value={recipientId} onChange={e=>setRecipientId(e.target.value)}><option value="">選択してください</option>{familyProfiles.filter(person=>person.is_active).map(person=><option key={person.id} value={person.id}>{person.display_name}</option>)}</select></label>
          <div className="inline-form"><input type="number" min="0" max="10000" value={initialCount} onChange={e=>setInitialCount(e.target.value)}/><span>枚</span><button className="secondary" disabled={busy || !recipientId} onClick={()=>rpc("admin_set_initial_count",{p_count:Number(initialCount),p_recipient_user_id:recipientId})}>設定</button></div>
        </div>
        <div className="admin-box">
          <h3><RotateCcw size={18}/> 残数リセット</h3>
          <p className="muted small-text">指定した枚数に戻します。過去の履歴は消えません。</p>
          <div className="inline-form"><input type="number" min="0" max="10000" value={resetCount} onChange={e=>setResetCount(e.target.value)}/><span>枚</span><button className="danger" disabled={busy} onClick={()=>setShowResetConfirm(true)}>リセット</button></div>
        </div>
        <div className="admin-box">
          <h3><Users size={18}/> アカウントについて</h3>
          <p className="muted small-text">新規登録した家族は初期状態では利用停止中です。管理者がSupabaseで有効化すると利用できます。管理者権限の付与もSupabase管理画面から行います。</p>
        </div>
      </section>}

      {message && <p className="notice">{message}</p>}
      <footer><span>肩たたき券 · 家族の約束</span><button onClick={signOut}><LogOut size={15}/>ログアウト</button></footer>

      {showUseConfirm && <Modal title="肩たたき券を使いますか？" body="お母さんへの肩たたき券を1枚使用します。この操作は履歴に記録されます。" confirm="確認して使う" onClose={()=>setShowUseConfirm(false)} onConfirm={async()=>{setShowUseConfirm(false);await rpc("use_ticket",{});}} busy={busy}/>}
      {showAddConfirm && <Modal title={`${addCount}枚追加しますか？`} body="追加操作と変更後の残数が履歴に記録されます。" confirm="追加する" onClose={()=>setShowAddConfirm(false)} onConfirm={async()=>{setShowAddConfirm(false);await rpc("admin_add_tickets",{p_count:Number(addCount)});}} busy={busy}/>}
      {showResetConfirm && <Modal title="残数をリセットしますか？" body={`残数を${resetCount}枚に変更します。過去の履歴は保持されます。`} confirm="リセットする" danger onClose={()=>setShowResetConfirm(false)} onConfirm={async()=>{setShowResetConfirm(false);await rpc("admin_reset_tickets",{p_count:Number(resetCount)});}} busy={busy}/>
      }
      {cancelId && <Modal title="使用を取り消しますか？" body="対象の使用記録を消さず、取り消しの記録を新しく追加します。" confirm="取り消す" danger onClose={()=>setCancelId(null)} onConfirm={async()=>{const id=cancelId;setCancelId(null);await rpc("admin_reverse_transaction",{p_transaction_id:id});}} busy={busy}/>}
    </main>
  );
}

function HistoryRow({tx}:{tx:Tx}) {
  const positive = tx.type==="add" || tx.type==="reverse";
  return <div className="history-row">
    <div className={`tx-icon ${positive?"positive":tx.type==="use"?"negative":""}`}><span>{tx.type==="use"?"−":tx.type==="add"||tx.type==="reverse"?"+":"↻"}</span></div>
    <div className="tx-main"><strong>{typeLabel(tx.type)}</strong><small>{dateLabel(tx.created_at)} · {tx.actor_name ?? "ユーザー"}</small>{tx.note && <small>{tx.note}</small>}</div>
    <div className="tx-value"><strong className={positive?"plus":tx.type==="use"?"minus":""}>{tx.type==="reset"?"変更":`${positive?"+":"−"}${tx.amount}枚`}</strong><small>{tx.balance_after}枚</small></div>
  </div>;
}

function Modal({title,body,confirm,onClose,onConfirm,danger=false,busy=false}:{title:string;body:string;confirm:string;onClose:()=>void;onConfirm:()=>void;danger?:boolean;busy?:boolean}) {
  return <div className="modal-backdrop" role="presentation"><section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
    <div className="modal-icon"><Hand size={25}/></div><h2 id="modal-title">{title}</h2><p>{body}</p>
    <div className="modal-actions"><button className="secondary" onClick={onClose} disabled={busy}>キャンセル</button><button className={danger?"danger":"primary"} onClick={onConfirm} disabled={busy}>{busy?"処理中…":confirm}</button></div>
  </section></div>;
}
