-- Shoulder Ticket: initial schema
-- Run this entire file in Supabase SQL Editor using the project owner account.
create extension if not exists pgcrypto;

create type public.app_role as enum ('admin', 'member');
create type public.transaction_type as enum ('use', 'add', 'reverse', 'reset');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete restrict,
  display_name text not null,
  role public.app_role not null default 'member',
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.ticket_accounts (
  id uuid primary key default gen_random_uuid(),
  recipient_user_id uuid not null references public.profiles(id) on delete restrict,
  initial_count integer not null check (initial_count >= 0),
  balance integer not null check (balance >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index one_ticket_account_per_recipient
  on public.ticket_accounts(recipient_user_id);

create table public.transactions (
  id uuid primary key default gen_random_uuid(),
  account_id uuid not null references public.ticket_accounts(id) on delete restrict,
  actor_user_id uuid references auth.users(id) on delete set null,
  actor_name text,
  type public.transaction_type not null,
  amount integer not null check (amount >= 0),
  balance_before integer not null check (balance_before >= 0),
  balance_after integer not null check (balance_after >= 0),
  reversal_of uuid references public.transactions(id) on delete restrict,
  note text,
  created_at timestamptz not null default now(),
  constraint reversal_unique unique(reversal_of)
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index transactions_created_at_idx on public.transactions(created_at desc);
create index transactions_account_id_idx on public.transactions(account_id, created_at desc);

-- Profile creation is member-only by default. Never trust role from signup metadata.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, display_name, role)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'display_name',''), split_part(new.email,'@',1)),
    'member'
  );
  return new;
end;
$$;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

alter table public.profiles enable row level security;
alter table public.ticket_accounts enable row level security;
alter table public.transactions enable row level security;
alter table public.audit_logs enable row level security;

create policy "users can read own profile and admins can read all"
  on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin() or is_active);
create policy "users can update own display name"
  on public.profiles for update to authenticated
  using (id = auth.uid() and role = 'member')
  with check (id = auth.uid() and role = 'member');
create policy "signed in users can read ticket account"
  on public.ticket_accounts for select to authenticated using (true);
create policy "signed in users can read transactions"
  on public.transactions for select to authenticated using (true);
create policy "admins can read audit logs"
  on public.audit_logs for select to authenticated using (public.is_admin());

-- No direct client writes to balance, transaction, or audit tables.
revoke insert, update, delete on public.ticket_accounts from anon, authenticated;
revoke insert, update, delete on public.transactions from anon, authenticated;
revoke insert, update, delete on public.audit_logs from anon, authenticated;
revoke update on public.profiles from anon, authenticated;
grant update(display_name) on public.profiles to authenticated;

create or replace function public.write_audit(p_action text, p_details jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public
as $$
begin
  insert into public.audit_logs(actor_user_id, action, details)
  values(auth.uid(), p_action, coalesce(p_details, '{}'::jsonb));
end;
$$;

create or replace function public.use_ticket()
returns jsonb language plpgsql security definer set search_path = public
as $$
declare a public.ticket_accounts%rowtype; actor text;
begin
  if auth.uid() is null then raise exception 'ログインしてください'; end if;
  if not exists(select 1 from public.profiles where id = auth.uid() and is_active = true) then
    raise exception 'このアカウントはまだ利用できません。管理者に確認してください';
  end if;
  select * into a from public.ticket_accounts order by created_at limit 1 for update;
  if not found then raise exception 'チケットがまだ設定されていません'; end if;
  if a.balance < 1 then raise exception '残り枚数がありません'; end if;
  select display_name into actor from public.profiles where id = auth.uid();
  update public.ticket_accounts set balance = balance - 1, updated_at = now() where id = a.id returning * into a;
  insert into public.transactions(account_id, actor_user_id, actor_name, type, amount, balance_before, balance_after, note)
  values(a.id, auth.uid(), actor, 'use', 1, a.balance + 1, a.balance, '肩たたき券を使用');
  perform public.write_audit('use_ticket', jsonb_build_object('account_id',a.id,'balance_after',a.balance));
  return jsonb_build_object('balance', a.balance);
end;
$$;

create or replace function public.admin_add_tickets(p_count integer)
returns jsonb language plpgsql security definer set search_path = public
as $$
declare a public.ticket_accounts%rowtype; actor text; before_count integer;
begin
  if not public.is_admin() then raise exception '管理者権限が必要です'; end if;
  if p_count is null or p_count < 1 or p_count > 10000 then raise exception '追加枚数は1〜10000枚にしてください'; end if;
  select * into a from public.ticket_accounts order by created_at limit 1 for update;
  if not found then raise exception '先にチケットを初期設定してください'; end if;
  before_count := a.balance;
  select display_name into actor from public.profiles where id = auth.uid();
  update public.ticket_accounts set balance = balance + p_count, updated_at = now() where id = a.id returning * into a;
  insert into public.transactions(account_id, actor_user_id, actor_name, type, amount, balance_before, balance_after, note)
  values(a.id, auth.uid(), actor, 'add', p_count, before_count, a.balance, '管理者による追加');
  perform public.write_audit('admin_add_tickets', jsonb_build_object('count',p_count,'balance_after',a.balance));
  return jsonb_build_object('balance',a.balance);
end;
$$;

create or replace function public.admin_set_initial_count(p_count integer, p_recipient_user_id uuid)
returns jsonb language plpgsql security definer set search_path = public
as $$
declare actor text; a public.ticket_accounts%rowtype;
begin
  if not public.is_admin() then raise exception '管理者権限が必要です'; end if;
  if p_count is null or p_count < 0 or p_count > 10000 then raise exception '初期枚数は0〜10000枚にしてください'; end if;
  if exists(select 1 from public.ticket_accounts) then
    raise exception '初期設定済みです。残数の変更にはリセット機能を使用してください';
  end if;
  if p_recipient_user_id is null or not exists(select 1 from public.profiles where id = p_recipient_user_id and is_active = true) then
    raise exception '券を受け取る家族を選択してください';
  end if;
  select display_name into actor from public.profiles where id = auth.uid();
  insert into public.ticket_accounts(recipient_user_id, initial_count, balance)
  values(p_recipient_user_id, p_count, p_count) returning * into a;
  insert into public.transactions(account_id, actor_user_id, actor_name, type, amount, balance_before, balance_after, note)
  values(a.id, auth.uid(), actor, 'reset', p_count, 0, p_count, '初期枚数を設定');
  perform public.write_audit('admin_set_initial_count', jsonb_build_object('initial_count',p_count));
  return jsonb_build_object('balance',a.balance);
end;
$$;

create or replace function public.admin_reset_tickets(p_count integer)
returns jsonb language plpgsql security definer set search_path = public
as $$
declare a public.ticket_accounts%rowtype; actor text; before_count integer;
begin
  if not public.is_admin() then raise exception '管理者権限が必要です'; end if;
  if p_count is null or p_count < 0 or p_count > 10000 then raise exception '残数は0〜10000枚にしてください'; end if;
  select * into a from public.ticket_accounts order by created_at limit 1 for update;
  if not found then raise exception 'チケットがまだ設定されていません'; end if;
  before_count := a.balance;
  select display_name into actor from public.profiles where id = auth.uid();
  update public.ticket_accounts set balance = p_count, updated_at = now() where id = a.id returning * into a;
  insert into public.transactions(account_id, actor_user_id, actor_name, type, amount, balance_before, balance_after, note)
  values(a.id, auth.uid(), actor, 'reset', abs(p_count-before_count), before_count, p_count, '管理者による残数リセット');
  perform public.write_audit('admin_reset_tickets', jsonb_build_object('before',before_count,'after',p_count));
  return jsonb_build_object('balance',a.balance);
end;
$$;

create or replace function public.admin_reverse_transaction(p_transaction_id uuid)
returns jsonb language plpgsql security definer set search_path = public
as $$
declare original public.transactions%rowtype; a public.ticket_accounts%rowtype; actor text; new_balance integer;
begin
  if not public.is_admin() then raise exception '管理者権限が必要です'; end if;
  select * into original from public.transactions where id = p_transaction_id;
  if not found then raise exception '対象の履歴が見つかりません'; end if;
  if original.type <> 'use' then raise exception '使用履歴のみ取り消せます'; end if;
  if exists(select 1 from public.transactions where reversal_of = p_transaction_id) then raise exception 'この使用はすでに取り消されています'; end if;
  select * into a from public.ticket_accounts where id = original.account_id for update;
  select display_name into actor from public.profiles where id = auth.uid();
  new_balance := a.balance + original.amount;
  update public.ticket_accounts set balance = new_balance, updated_at = now() where id = a.id;
  insert into public.transactions(account_id, actor_user_id, actor_name, type, amount, balance_before, balance_after, reversal_of, note)
  values(a.id, auth.uid(), actor, 'reverse', original.amount, a.balance, new_balance, p_transaction_id, '管理者による使用取り消し');
  perform public.write_audit('admin_reverse_transaction', jsonb_build_object('original_transaction_id',p_transaction_id,'balance_after',new_balance));
  return jsonb_build_object('balance',new_balance);
end;
$$;

revoke all on function public.write_audit(text, jsonb) from public;\nrevoke all on function public.use_ticket() from public;
revoke all on function public.admin_add_tickets(integer) from public;
revoke all on function public.admin_set_initial_count(integer, uuid) from public;
revoke all on function public.admin_reset_tickets(integer) from public;
revoke all on function public.admin_reverse_transaction(uuid) from public;
grant execute on function public.use_ticket() to authenticated;
grant execute on function public.admin_add_tickets(integer) to authenticated;
grant execute on function public.admin_set_initial_count(integer, uuid) to authenticated;
grant execute on function public.admin_reset_tickets(integer) to authenticated;
grant execute on function public.admin_reverse_transaction(uuid) to authenticated;
grant execute on function public.is_admin() to authenticated;

-- INITIAL SETUP AFTER FIRST ADMIN SIGNUP:
-- 1. Find your user UUID in Authentication > Users.
-- 2. Run:
-- update public.profiles set role = 'admin', is_active = true where id = 'YOUR-USER-UUID';\n-- 3. Activate your mother's account after she signs up:\n-- update public.profiles set is_active = true where id = 'MOTHERS-USER-UUID';
-- 3. Sign in as admin and use the app's initial-count setup.
-- 4. Sign up your mother's account separately. It remains role='member'.
